const synthetic={
messages:[
["WhatsApp","08:41","Synthetic contact","The evidence package is ready for review."],
["Instagram","09:12","Synthetic account","Meeting moved to 14:30. Confirm attendance."],
["SMS","10:05","Service","Verification event recorded in the demo dataset."],
["WhatsApp","11:26","Synthetic contact","Please send the reference number."],
["Instagram","13:48","Synthetic account","Received. I will review the documents."]
],
artifacts:[["Messages","24"],["Images","18"],["Contacts","31"],["Locations","12"],["Documents","09"],["App events","37"]],
indicators:[["demo-target.example","Domain","LOW"],["198.51.100.42","IP","MEDIUM"],["demo@example.test","Email","LOW"],["AS-DEMO-01","ASN","LOW"],["SIM-URL-8841","URL","MEDIUM"]],
timeline:[
["08:10","Evidence container opened","Synthetic evidence set initialized for demonstration."],
["08:22","Artifact indexing","Messages, media and application records indexed."],
["09:04","Correlation completed","Synthetic identity records cross-referenced."],
["10:17","Network analysis","Demo indicators grouped by infrastructure relationship."],
["11:42","Risk assessment","Risk score calculated from simulated indicators."]
]};
const $=s=>document.querySelector(s);
const $$=s=>document.querySelectorAll(s);
function showView(id){
  $$('.view').forEach(v=>v.classList.remove('active')); $('#'+id).classList.add('active');
  $$('.nav').forEach(n=>n.classList.toggle('active',n.dataset.view===id));
  const titles={overview:"Case Overview",identity:"Identity Intelligence",communications:"Communications",device:"Device Evidence",network:"Network Intelligence",timeline:"Evidence Timeline"};
  $('#pageTitle').textContent=titles[id]||"Investigation Console";
}
$$('.nav').forEach(n=>n.onclick=()=>showView(n.dataset.view));
function renderFeed(){
 const items=["Evidence container verified","Identity correlation complete","Communication artifacts indexed","Network indicators classified","Report workspace synchronized"];
 $('#feed').innerHTML=items.map((x,i)=>`<div><b>${String(i+1).padStart(2,'0')}</b> ${x} <span style="float:right">DEMO</span></div>`).join('');
}
function renderMessages(){
 const q=($('#msgSearch').value||'').toLowerCase(), f=$('#appFilter').value;
 $('#messages').innerHTML=synthetic.messages.filter(m=>(f==="All sources"||m[0]===f)&&m.join(' ').toLowerCase().includes(q))
 .map(m=>`<article class="message"><div class="meta"><b>${m[0]}</b><span>${m[1]} • ${m[2]}</span></div><p>${m[3]}</p></article>`).join('')||'<p class="muted">No synthetic records match.</p>';
}
function renderArtifacts(){$('#artifacts').innerHTML=synthetic.artifacts.map(a=>`<div class="artifact"><b>${a[1]}</b><span>${a[0]}</span></div>`).join('')}
function renderIndicators(){$('#indicators').innerHTML=synthetic.indicators.map(x=>`<div class="indicator"><span>${x[0]}<small style="display:block;color:#687789">${x[1]}</small></span><strong>${x[2]}</strong></div>`).join('')}
function renderTimeline(){$('#timelineList').innerHTML=synthetic.timeline.map(x=>`<div class="event"><time>${x[0]}</time><h4>${x[1]}</h4><p>${x[2]}</p></div>`).join('')}
function toast(t){$('#toast').textContent=t;$('#toast').style.display='block';setTimeout(()=>$('#toast').style.display='none',2200)}
$('#msgSearch').oninput=renderMessages; $('#appFilter').onchange=renderMessages;
$('#runDemo').onclick=()=>{toast('Demo analysis completed — synthetic data only.');$('#riskScore').textContent=Math.floor(68+Math.random()*9);renderFeed()};
renderFeed();renderMessages();renderArtifacts();renderIndicators();renderTimeline();
